library(testthat)
library(LncPipeReporter)

test_check("LncPipeReporter")
