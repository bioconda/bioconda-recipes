This is the `include` directory, `readme.md` and `license.txt` from the [rapidjson](https://github.com/miloyip/rapidjson/commits/master) library.

This is extracted from commit b8f0414b9a7cd4c78171363240b581b26d3cf513 of that repo.

This includes only the `include` (and `readme.md` and `license.txt`) directory to avoid the infamous JSON license applying.
