
This is the source code for the software named Genclust.

Everything contained here is copyrighted and is available for your use
and redistribution under certain license terms.  Please read
COPYING.TXT for more information.

For information about this software contact one of the authors: lobosco@math.unipa.it.

