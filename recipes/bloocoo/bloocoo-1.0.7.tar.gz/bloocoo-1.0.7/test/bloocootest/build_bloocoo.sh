#!/bin/sh

pwd=$PWD


cd ~/workspace/gatb-tools/gatb-tools/tools/bloocoo/build/
make Bloocoo

cp Bloocoo ~/workspace/gatb-tools/gatb-tools/tools/bloocoo/test/bloocootest/irisa


