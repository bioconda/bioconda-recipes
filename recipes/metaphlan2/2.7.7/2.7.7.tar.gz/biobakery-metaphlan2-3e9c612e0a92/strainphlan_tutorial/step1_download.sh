#!/bin/bash
wget 
bunzip2 
