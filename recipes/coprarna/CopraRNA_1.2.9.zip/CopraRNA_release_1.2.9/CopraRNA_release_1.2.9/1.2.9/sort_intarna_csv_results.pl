#!/usr/bin/perl

################################################################################
##
##    sort_intarna_csv_results.pl sorts a semicolon separated list with IntaRNA 
##    results by a given column and prints the sorted list.
##    Optionally, it prints only the rank of a given target in the sorted list.
##
################################################################################

use warnings;
use strict;
use Getopt::Long;



my $help = '';   
my $intarna_csv_file = undef;
my $column_to_sort = undef;  
my $target_name = undef;    

GetOptions ('help|?' => \$help, 
    'intarna-csv-file=s' => \$intarna_csv_file,
    'column=i' => \$column_to_sort,
    'target=s' => \$target_name,
);

if ($help) {
print "\nThe script sorts a semicolon separated list with IntaRNA results by ",
"a given column and prints the sorted list.\n",
"The program assumes that there is a header in the first line.\n",
"Optionally, it prints only the rank of a given target in the sorted list.\n\n",

"The following options are available:\n",
" --intarna-csv-file file    semicolon separated list with IntaRNA results\n",
" --column number        sort list by this column (counts from 1),\n",
     "                print sorted list if no target name is given\n",
" --target name            print rank of this target in the sorted list\n",
" --help                this help\n\n";

exit(-1);
}

die "No semicolon separated list with IntaRNA results specified. Please use ",
    "--intarna-csv-file filename.\n" if (!defined($intarna_csv_file));
die "No column for sorting specified. Please use --column number.\n" 
    if (!defined($column_to_sort));


open(FILE, $intarna_csv_file) || 
    die "ERROR: Could not open $intarna_csv_file\n";
my @results = <FILE>;
close(FILE);
chomp(@results);

my @temp = map { [$_, split /;/] } @results[1..$#results];

$column_to_sort -= 1; 
@temp = sort {
    my @a_fields = @$a[1..$#$a];
    my @b_fields = @$b[1..$#$b];
    $a_fields[$column_to_sort] <=> $b_fields[$column_to_sort];
} @temp;

my @sorted_results = map { $_->[0] } @temp;
unshift(@sorted_results,$results[0]);

if (!defined($target_name)) {
    foreach my $i (@sorted_results) {
        print $i,"\n";
    }
}
else {
    my $found = 0;  
    for (my $i=1; $i<=$#sorted_results; $i++) {
        if ($sorted_results[$i] =~ /$target_name/) {
            $found = 1;
            print $i,"\n";
            last; 
        }
    }
    print "NA\n" unless ($found);
}

