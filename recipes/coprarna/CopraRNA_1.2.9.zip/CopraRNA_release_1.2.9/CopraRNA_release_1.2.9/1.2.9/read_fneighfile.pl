#!/usr/bin/perl 

use warnings;
use strict;

my $treefile = $ARGV[0];
my $fneighfile = $ARGV[1];

open(MYDATA, $treefile) or die("Error: cannot open file $treefile'\n");
my @treefilelines = ();
@treefilelines = <MYDATA>;
close MYDATA;


my $treelength = 0;

foreach(@treefilelines) {
    chomp $_;
    my @splitarray = split(/:/, $_);
    foreach(@splitarray) {
        if($_ =~ m/\S*(\d\.\d+)/) {
            $treelength = $treelength + $1;
        }
    }
}



open(MYDATA, $fneighfile) or die("Error: cannot open file $fneighfile'\n");
my @fneighfilelines = ();
    @fneighfilelines = <MYDATA>;
close MYDATA;

my $theorgcnt = 0;

foreach(@fneighfilelines) {
    if($_ =~ m/(\d+)\sPopulations/) {
        $theorgcnt = $1;
        chomp $theorgcnt;
    }
}

my @lastlines = ();
my $switch = 0;

foreach(@fneighfilelines) {
    chomp $_;
    if($_ =~ m/remember:.+!/) {
        $switch = 1;   
    }
    if($switch) {
        if($_ =~ m/\d/) {
            push @lastlines, $_;
        }
    }
}

my $tripleroot = 0;
my $thetripleswitch = 1;

### made an edit here and changed it to split instread of substr  ## edit 1.2.3
foreach(@lastlines) {
    my $c = 0;
    $_ =~ s/^\s+//;
    $_ =~ s/\s+$//;
    my @split1 = split(/\s+/, $_);
    my $firstchar = $split1[0];
    foreach(@lastlines) {
        $_ =~ s/^\s+//;
        $_ =~ s/\s+$//;
        my @split2 = split(/\s+/, $_);
        my $firstchar2 = $split2[0];
        if($firstchar2 == $firstchar) {
            $c++;
        }
    }
    if($c == 3) {
        $tripleroot = $firstchar;
        $thetripleswitch = 0;
    } 
}

if($thetripleswitch) { print "no tripleroot in the $fneighfile !!\n"; }

my @triplerootarray = ();
my %weighthash = ();

my $lastlinecnt = 0;
my @splicearray = ();

foreach(@lastlines) {
    $_ =~ s/-/ /;
    my @split = split(/\s+/,$_);
    if($split[0] == $tripleroot) {
        push(@triplerootarray, $_);
        push(@splicearray, $lastlinecnt) if($split[1] =~ m/nc/);
        if(not $split[1] =~ m/nc/) {
            my $tempsplit2halfed = $split[2]/2;
            my $temp = join(' ', $split[0], $split[1], $tempsplit2halfed);
            $lastlines[$lastlinecnt] = $temp;
        }
    }
    $lastlinecnt++;
}

my @triplerootrefseqs = ();

foreach(@triplerootarray) { 
    my @split = split(/\s+/,$_);
    foreach(@split) {
        if($split[1] =~ m/nc/) {
            push(@triplerootrefseqs, $split[1]);
        }
    }
}

my $idvalofinterest = 0;
my $doublenums = 0;
my $scndidval = 0;

foreach my $refseqid (@triplerootrefseqs) {
    foreach(@triplerootarray) {
        my @split = split(/\s+/,$_);
        if($_ =~ m/$refseqid/) {
            $idvalofinterest = $split[2];
        } else {
            if(not $split[1] =~ m/nc/) {
                $doublenums = ($split[2]/2);
            } else {
                if($split[1] =~ m/nc/) {
                    $scndidval = $split[2];
                }
            }
        }
    }
    my $result = 0;
    unless ($treelength == 0) {
        $result = (($idvalofinterest+($doublenums/2))/($idvalofinterest+$doublenums+$scndidval)) * (($idvalofinterest+$doublenums+$scndidval)/$treelength) unless ($theorgcnt==3); ## edit 1.2.8 division by zero issue for two equal organisms in a 3 organism job -> forward the problem to the 3 org part to fix
    } else {
        $result = 1/$theorgcnt; ## edit 1.2.8 fixed division by zero error for trees with length zero
    }
$weighthash{$refseqid} = $result;
}

@splicearray = sort { $a <=> $b } (@splicearray);

foreach(@splicearray) {
    splice(@lastlines, $_, 1);
    foreach(@splicearray) {
        $_ = $_ - 1;
    }
}    

my %tree = ();


foreach(@lastlines) {
    my @split = split(/\s+/,$_);
    $tree{$split[0]}{$split[1]} = $split[2];
}

my %flippedtree = ();

foreach(@lastlines) {
    my @split = split(/\s+/,$_);
    $flippedtree{$split[1]}{$split[0]} = $split[2];
}


my @refseqarray = ();

for my $key (keys %tree) {
    for my $key2 (keys %{$tree{$key}}) {
        if($key2 =~ m/nc/) {
            push @refseqarray, $key2;
        }
    }
}


my %subtreelengthhash = ();

#edit the substring here ## edit 1.2.3
foreach(@lastlines) {
    $_ =~ s/^\s+//;
    $_ =~ s/\s+$//;
    my @split = split(/\s+/, $_);
    my $nodenum = $split[0];
    if ($nodenum ne $tripleroot) {
        $subtreelengthhash{$nodenum} = &subtreelength($nodenum, \%tree);
    }
}


foreach my $refid (@refseqarray) {
for my $root (keys %{$flippedtree{$refid}}) {
    for my $rootlength (keys %{$flippedtree{$root}}) {
        $weighthash{$refid} = &calctree($root, $flippedtree{$refid}{$root}, \%flippedtree, $tripleroot, $flippedtree{$root}{$rootlength}, \%subtreelengthhash, $treelength, $theorgcnt);
    }
}
}



sub subtreelength 
{
    (my $nodenum, my $hashref) = @_;

    my $subtreelength = 0;
    my %localhash = %{$hashref};
    for my $key (keys %{$localhash{$nodenum}}) {
        if($key =~ m/nc/) {
            $subtreelength = $subtreelength + $localhash{$nodenum}{$key};
        } else {
            $subtreelength = $subtreelength + $localhash{$nodenum}{$key} + &subtreelength($key, \%localhash);
        }
    }
    return $subtreelength;
}



sub calctree
{ ## edit 1.2.8 added orgcnt to input arguments for division by zero error  
    (my $root, my $branchlength, my $treeref, my $tripleroot, my $rootlength, my $subtreelengthsref, my $treelength, my $orgcnt) = @_;
    my $result = 1;
    my %localtree = %{$treeref};
    my %localsubtree = %{$subtreelengthsref};
    for my $nextroot (keys %{$localtree{$root}}) {
        if ($nextroot == $tripleroot) {
            unless ($treelength == 0) { ## edit 1.2.8 fix divide by zero bug for treelength 0
                 $result = (($branchlength + ($localtree{$root}{$nextroot}/2)) / ($localsubtree{$root} + $localtree{$root}{$nextroot})) *
                                (($localsubtree{$root} + $localtree{$root}{$nextroot}) / $treelength);
            } else {
                $result = 1/$orgcnt;
            }
        } else {
            my $nextsubtree = $localsubtree{$root}+$localtree{$root}{$nextroot};
            my $nextrootlength = 0;
            for my $thenextroot (keys %{$localtree{$nextroot}}) {
                $nextrootlength = $localtree{$nextroot}{$thenextroot};
            }
            unless ($treelength == 0) { ## edit 1.2.8 fix divide by zero bug for treelength 0
                $result = ($branchlength + ($localtree{$root}{$nextroot}/2))/($localsubtree{$root}+$localtree{$root}{$nextroot}) *
                &calctree($nextroot, $nextsubtree, \%localtree, $tripleroot, $nextrootlength, \%localsubtree, $treelength, $theorgcnt);
            } else {
                $result = 1/$orgcnt;
            }
        }
    }
    return $result;
}

if ($theorgcnt == 3) {
    %weighthash = ();

    my @splitzero = split(/\s+/, $triplerootarray[0]);
    my @splitone = split(/\s+/, $triplerootarray[1]);
    my @splittwo = split(/\s+/, $triplerootarray[2]);

    unless ($treelength == 0) {  ## edit 1.2.8 fixed division by zero error         
        my $resultzero = (($splitzero[2]+($splitone[2]/4))/($splitzero[2]+$splittwo[2]+($splitone[2]/2)))*(($splitzero[2]+$splittwo[2]+($splitone[2]/2))/$treelength);
        $weighthash{$splitzero[1]} = $resultzero;
        my $resultone = ($splitone[2]/2)/$treelength;
        $weighthash{$splitone[1]} = $resultone;
        my $resulttwo = (($splittwo[2]+($splitone[2]/4))/($splitzero[2]+$splittwo[2]+($splitone[2]/2)))*(($splitzero[2]+$splittwo[2]+($splitone[2]/2))/$treelength);
        $weighthash{$splittwo[1]} = $resulttwo;
    } else {
        $weighthash{$splitzero[1]} = 1/$theorgcnt;
        $weighthash{$splitone[1]} = 1/$theorgcnt;
        $weighthash{$splittwo[1]} = 1/$theorgcnt;
    }
}

   
for my $entry (keys %weighthash) {
    print "$entry;$weighthash{$entry}\n";
}




