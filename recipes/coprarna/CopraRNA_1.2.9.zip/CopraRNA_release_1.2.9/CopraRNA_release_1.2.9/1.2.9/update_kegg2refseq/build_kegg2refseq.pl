#!/usr/bin/perl

use warnings;
use strict;

# usage
# ../build_kegg2refseq.pl

system "wget ftp://ftp.ncbi.nih.gov/genomes/GENOME_REPORTS/prokaryotes.txt";

open MYDATA, "prokaryotes.txt" or die("ERROR: Can't open prokaryotes.txt\n");
    my @genomeInfo = <MYDATA>;
close MYDATA;

# open writing file handles
open (HP, '>CopraRNA_available_organisms.tmp');
open (Old, '>kegg2refseq.csv');
open (New, '>kegg2refseqnew.csv');

my %rdmStringHash = ();
my %printedHash = ();


foreach my $line (@genomeInfo) {
    my $printLineHP = "";
    my $printLineOld = "";
    my $printLineNew = "";
    my $switch = 1;
    if ($line =~ m/NC_\d{6}/) {
        my $rdmString = &generate_random_string(4);
        
        # make sure no duplicate letter codes are present
        while ($switch) {
            if (exists $rdmStringHash{$rdmString}) {
                $rdmString = &generate_random_string(4);
            } else {
                $switch = 0;
                $rdmStringHash{$rdmString} = "exists";
                $printLineOld = $rdmString . "\t";
                $printLineNew = $rdmString . "\t";
            }
        }

        my @splitLine = split(/\t/, $line);
        my $printedRefSeqCounter = 1;
        foreach my $entry (@splitLine) {
            if ($entry =~ m/NC_\d{6}/) {
                my @splitComma = split(/,/, $entry); 
                foreach my $subEntry (@splitComma) {
                    if ($subEntry =~ m/(NC_\d{6})/) {
                        my $RID = $1;
                        chomp $RID;
                        $printLineHP = $printLineHP . $RID . " ";
                        $printLineOld = $printLineOld . $RID . " " unless($printedRefSeqCounter>1);
                        $printLineNew = $printLineNew . $RID . " ";
                        $printedRefSeqCounter++;
                    }
                }
            }
        }
        $printLineHP =~ s/\s+$//;
        $printLineOld =~ s/\s+$//;
        $printLineNew =~ s/\s+$//;
        my $orgName = $splitLine[0];
        $orgName =~ s/^\s+//;
        $orgName =~ s/\s+$//;
        $orgName =~ s/\s+/_/g;
        $printLineHP = $printLineHP . "\t" . $orgName . "\n";
        $printLineOld = $printLineOld . "\n";
        $printLineNew = $printLineNew . "\n";
 
        # don't print same line twice
        print HP $printLineHP unless (exists $printedHash{$printLineHP});
        print Old $printLineOld unless (exists $printedHash{$printLineHP});
        print New $printLineNew unless (exists $printedHash{$printLineHP});

        $printedHash{$printLineHP} = "exists";
    }
}

# close writing file handles
close (HP);
close (Old);
close (New);

system "../add_date_omit_incompatible.sh";

sub generate_random_string
    {
	my $length_of_randomstring=shift;# the length of 
        my @chars=('a'..'z');
	my $random_string;
	foreach (1..$length_of_randomstring) 
	{
            $random_string.=$chars[rand @chars];
	}
	return $random_string;
    }

# usage
# my $random_string=&generate_random_string(4);


