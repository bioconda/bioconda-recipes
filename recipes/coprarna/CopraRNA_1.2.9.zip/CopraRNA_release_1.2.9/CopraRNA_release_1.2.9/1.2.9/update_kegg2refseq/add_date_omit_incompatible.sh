
# omit incompatible / screwed up genomes
sed -i '/NC_003198/d' kegg2refseqnew.csv
sed -i '/NC_003198/d' CopraRNA_available_organisms.tmp
sed -i '/NC_003198/d' kegg2refseq.csv
sed -i '/NC_004088/d' kegg2refseqnew.csv
sed -i '/NC_004088/d' CopraRNA_available_organisms.tmp
sed -i '/NC_004088/d' kegg2refseq.csv
sed -i '/NC_020504/d' kegg2refseqnew.csv
sed -i '/NC_020504/d' CopraRNA_available_organisms.tmp
sed -i '/NC_020504/d' kegg2refseq.csv
sed -i '/NC_022785/d' kegg2refseqnew.csv
sed -i '/NC_022785/d' CopraRNA_available_organisms.tmp
sed -i '/NC_022785/d' kegg2refseq.csv
sed -i '/NC_018220/d' kegg2refseqnew.csv
sed -i '/NC_018220/d' CopraRNA_available_organisms.tmp
sed -i '/NC_018220/d' kegg2refseq.csv

# make help list for webserver
echo -e "## last updated: \c" > Date.txt; date >> Date.txt
cat Date.txt ../head.txt > fullhead.txt
cat fullhead.txt CopraRNA_available_organisms.tmp > CopraRNA_available_organisms.txt

