# download a RefSeq record from the NCBI
# usage: ./get_refseq_from_ftp.sh NC_XXXXXX

lftp -q -c "open ftp://ftp.ncbi.nlm.nih.gov/genomes/Bacteria; ls */$1.gbk > location.txt" ## edit 1.2.2

loc=`awk '{print $NF}' location.txt`
wget --quiet ftp://ftp.ncbi.nlm.nih.gov/genomes/Bacteria/$loc -O $1.gb ## edit 1.2.2

rm location.txt
