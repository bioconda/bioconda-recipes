
pvals <- read.table("CopraRNA_pvalues.txt", header=TRUE)

pvals <- unlist(pvals)

padj <- p.adjust(pvals, method="BH") ## edit 1.2.9 Benjamini Hochberg instead of qvalue

write.table(padj,file="padj.csv", row.names=F, col.names='fdr') ## edit 1.2.9 changed col.names to fdr

