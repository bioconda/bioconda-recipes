#!/usr/bin/perl

use strict;
use warnings;
use List::MoreUtils qw(uniq); # liblist-moreutils-perl

print "locus_tag;target_start_pos;target_end_pos;sRNA_name;sRNA_start_pos;sRNA_end_pos;energy;p-value;clusternumber\n";

my $homologlist = $ARGV[0];

open(MYDATA, $homologlist) or die("Error: cannot open file $homologlist'\n");

my $c = 0;
my %hash = (); 
my $clustercount = 1;

while( my $line = <MYDATA> ) {
    if (not $line =~ m/^#|^running/) {
        my @tagarray = ();  
        my @linecontent = split(/\t/, $line); # split line by tabs
        for (my $i=1; $i<scalar(@linecontent); $i++) {
            my @splitline = split(/ /,$linecontent[$i]); # split the already splitted by spaces
                foreach (@splitline) {
                    my $temp = $_;
                    chomp $temp;
                    $temp =~ s/\w{3,}://;
                    push(@tagarray, lc($temp));
                }
        }

    foreach(@tagarray) { # there is no issue with duplicate keys, as duplicates in the table are named locus_tag(int)
        push(@{ $hash{ lc($_) }}, @tagarray);
    }
    }
}


close MYDATA;

my $switch = 1;
my %targethash = ();

foreach ( @ARGV ) {

open(MYDATA, $_);
my @array = ();
    while (my $line = <MYDATA>) {
        if ($switch <= 1) { 
            close MYDATA;    
            $switch++;      
            last;
        }
        if ($line =~ m/target_name/)  {
            next;
        } else {
            my @splitarray = split(/;/,$line); # split by semicolons
            my $ltag = $splitarray[0];
            push(@{ $targethash{ lc($ltag) }}, @splitarray);
            for(my $i=1;$i<=10;$i++) {   
                my $newltag = $ltag . "(" . $i . ")";  
                push(@{ $targethash{ lc($newltag) }}, @splitarray); 
            }                                            
        } 
    }
}


my $switcheroo = 0;
my $printline = "";
my @printlinearray = ();

foreach my $entry (keys %targethash) {                        
    if (exists $hash{ lc($entry)}) {
       foreach ( @{$hash{ lc($entry) }} ) {                   
           if (exists $targethash{ lc($_) }) {                
               foreach ( @{$targethash { lc($_) }}  ) {       
                   chomp $_;
                   $_ = reverse $_;
                   chomp $_;
                   $_ = reverse $_;
                   $printline = $printline . lc($_) . ";";
                   $switcheroo = 1;
               }
           }
       if ( $switcheroo ) {
           chop $printline;
           push (@printlinearray, $printline);
           $switcheroo = 0;
           $printline = '';
       }
       }
    }
foreach ( @{$hash{ lc($entry) }} ) {
    delete($hash{ lc($_) });
}

my @printlinearraysmall = ();
my $switchy = 1;
my $duplicswitch = 1;

foreach my $first ( @printlinearray ) {
    my @splitlinearray = split(/;/, $first);
        foreach my $second ( @printlinearray ) {
            if ($first eq $second) {
                next;
            }
        my @splitlinearray2 = split(/;/, $second);
            if($splitlinearray[3] eq $splitlinearray2[3]) {
                if($splitlinearray[6] >= $splitlinearray2[6]) {
                    $switchy = 0;
                    last;
                }
                if($splitlinearray[6] eq $splitlinearray2[6] and $duplicswitch) {
                    push (@printlinearraysmall, $first);
                    $switchy = 0;
                    $duplicswitch = 0;
                    last;
                } 
            }
        }

if ($switchy) {
    push (@printlinearraysmall, $first);
}
$switchy = 1;
$duplicswitch = 1;
}
@printlinearraysmall = uniq(@printlinearraysmall);
foreach ( @printlinearraysmall ) {
print $_ . ";" . $clustercount . "\n"; 
}
if (scalar(@printlinearraysmall)) {
$clustercount++;
}
@printlinearray = ();
}

 
