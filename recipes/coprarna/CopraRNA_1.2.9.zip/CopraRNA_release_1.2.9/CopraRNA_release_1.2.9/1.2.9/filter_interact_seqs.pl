#!/usr/bin/perl

use strict;
use warnings;

my $hintarnaout = $ARGV[0];
my $parsedfasta = $ARGV[1];

my @fastalines = ();
my %fastahash = ();
my $header = '';

open(MYDATA, $parsedfasta) or die("Error: cannot open file: " . $parsedfasta . "\n");

@fastalines = <MYDATA>;

close MYDATA;

my $theseq = '';
my $switch = 0;

foreach (@fastalines) {
    chomp $_;
    if ($_ =~ m/>/) {
        if ($switch) {
            $fastahash{$header} = $theseq;
            $theseq = '';
        }
        $_ = reverse $_;
        chomp $_;
        chop $_;
        $_ = reverse $_;
        $header = lc($_);
    } else {
        $theseq = $theseq . $_;
        $switch = 1;
    }
}

$fastahash{$header} = $theseq;

my @hintarnaoutlines = ();


open(MYDATA, $hintarnaout) or die("Error: cannot open file: " . $hintarnaout . "\n");

@hintarnaoutlines = <MYDATA>;

close MYDATA;

my @headersplit = ();

foreach (@hintarnaoutlines) {
    chomp $_;
    if ($_ =~ m/^pvalue/) {
        @headersplit = split(/,/, $_);
        pop @headersplit;
        pop @headersplit;
        shift @headersplit; 
    } else {

        my @splitlines = split(/,/, $_);
        my $c = 0;
        foreach(@splitlines) {
            chomp $_;
            if($_ =~ m/^(.*)\(.*\|.*\|.*\|(.*)\|(.*)\|.*\|.*\|.*\)/) {
                my $ltag = $1;
                my $start = $2;
                my $stop = $3;
                my $length = $stop - $start;
                if (exists $fastahash{$ltag}) {
                    print ">$ltag\n";
                    my $seq = substr $fastahash{$ltag}, $start, $length;
                    print $seq . "\n";
                }
            }
            $c++;
        } 
    }
}





