#!/usr/bin/perl

# CopraRNA 1.2.9

# When using CopraRNA please cite:
# Patrick R. Wright, Andreas S. Richter, Kai Papenfort, Martin Mann, Jörg Vogel, Wolfgang R. Hess, Rolf Backofen and Jens Georg
# Comparative genomics boosts target prediction for bacterial small RNAs
# Proc Natl Acad Sci USA, 2013, 110(37), E3487–E3496.

# and/or

# Patrick R. Wright, Jens Georg, Martin Mann, Dragos A. Sorescu, Andreas S. Richter, Steffen Lott, Robert Kleinkauf, Wolfgang R. Hess, and Rolf Backofen
# CopraRNA and IntaRNA: predicting small RNA targets, networks and interaction domains
# Nucleic Acids Research, 2014

# If you run into problems or have questions, please do not hesitate to
# contact us.
# rna@informatik.uni-freiburg.de

                     
#    Comparative prediction algorithm for sRNA targets       
#    CopraRNA
#    by: 
#    Patrick R. Wright              
#    Andreas S. Richter 
#    Kai Papenfort
#    Martin Mann
#    Joerg Vogel
#    Wolfgang R. Hess
#    Rolf Backofen
#    Jens Georg

#####################################################

use strict;
use warnings;

##### dependencies:

### Bio Software

# IntaRNA 1.2.5 (which needs Vienna package 1.8.5)
# EMOBOSS package 6.3.1 - emma(clustalw wrapper), distmat(creates distance matix from msa)
# embassy phylip 3.69 - fneighbor (creates neighbor joining tree from distance matrix)
# ncbiblast-2.2.15 and 2.2.25
# clustalw 2.1

### Perl Module(s):

# Statistics::R 0.26
# List::MoreUtils # liblist-moreutils-perl
# Parallel::ForkManager # libparallel-forkmanager-perl
# Getopt::Long
# Bio::SeqIO
# Bio::DB::EUtilities
# SOAP::Lite
# HTTP::Cookies

### R Package(s):

# R statistics 2.14 or higher
# evir
# seqinr

################################################################################################


### change the ($versiondirectory) variable in:
# homology_intaRNA.pl
# get_CDS_from_gbk.pl
# prepare_intarna_out.pl 
# scale_clusters.pl 

### edit calc_padj.r path in add_padj.sh
 
my $versiondirectory = "/home/user/Bio_Software/CopraRNA/1.2.9/";

my $ncrnas = $ARGV[0]; # input_sRNA.fa
my $upfromstartpos = $ARGV[1]; # 200
my $down = $ARGV[2]; # 100
my $mrnapart = $ARGV[3]; # cds or 5utr or 3utr
my $mergedinput = "";
my $orgcount = 0;
my $ncrnaname = "";

if (scalar(@ARGV) < 1) { ## edit 1.2.7
    die("Error: No input arguments supplied!\nPlease set input accordingly:\nhomology_intaRNA.pl [sRNAs - fasta] [ntupsteam - integer] [ntdownstream - integer] [region - one of 5utr,3utr,cds] [RefSeq IDs - string]\n");
}

system "grep '-' $ncrnas > find_gaps.txt"; ## edit 1.2.7
system "grep '-' $ncrnas"; ## edit 1.2.7
if (-s "find_gaps.txt") { die("Error:Gaps are present in sRNA sequences. Please delete them from the file and restart\n"); } ## edit 1.2.7

open(WRITETO, '>coprarna_pars.txt');
    print WRITETO "$mrnapart\n$upfromstartpos\n$down\n";
close(WRITETO);

my $tripletorefseqnewfile = $versiondirectory . "kegg2refseqnew.csv";
my %refseqaffiliations = ();

open(MYDATA, $tripletorefseqnewfile) or die("Error: cannot open file $tripletorefseqnewfile\n");
    my @triptorefseqnew = <MYDATA>;
close MYDATA;

foreach(@triptorefseqnew) {
    my @split = split("\t", $_);
    my @split2 = split(" ", $split[1]);
    foreach(@split2) {
        chomp $split[1];#these are refseqids
        $refseqaffiliations{$_} = $split[1];
    }
}


########################################
##                                    ##
## put ncRNA fasta together propperly ##
##                                    ##
########################################

my $mergedforputtogether = "";

for ( my $i=4; $i<scalar(@ARGV); $i++ ) {
    my @split = split(/\s/, $refseqaffiliations{$ARGV[$i]});
    $mergedforputtogether = $mergedforputtogether . $split[0] . " ";
}
chop $mergedforputtogether;


print $versiondirectory . "put_ncRNA_fasta_together.pl $ncrnas $mergedforputtogether > ncrna.fa\n";

system $versiondirectory . "put_ncRNA_fasta_together.pl $ncrnas $mergedforputtogether > ncrna.fa";

####################
##                ##
## get Orgcount   ##
##                ##
####################

$orgcount = (scalar(@ARGV) - 4);

######################
##                  ##
## get ncRNA Name   ##
##                  ##
######################

$ncrnas = "ncrna.fa";

open(MYDATA, $ncrnas) or die("Error: cannot open file $ncrnas'\n");
    while ( my $line = <MYDATA> ) {
        if ($line =~ m/>(\S+)_NC_\d+/){
            chomp $1;
            $ncrnaname = lc($1);
        }
        last;
    }
close MYDATA;

#############################################
##                                         ##
## prepare input for scale_clusters.pl     ##
##                                         ##
#############################################

for ( my $i=4; $i<=(scalar(@ARGV) - 1); $i++ ) {
    $ARGV[$i] = uc($ARGV[$i]);
    my @replikons = split(/,/, $ARGV[$i]);
    foreach(@replikons) {
        $mergedinput = $mergedinput . $_ . ".gb" . ",";
    }
    chop $mergedinput;
    $mergedinput = $mergedinput . " ";
}

chop $mergedinput;


######################################################################################
##                                                                                  ##
## Download Refseq files by Refseq ID and check for availability in kegg2refseq.csv ##
##                                                                                  ##
######################################################################################

my $tripletorefseq = $versiondirectory . "kegg2refseq.csv";

open(MYDATA, $tripletorefseq) or die("Error: cannot open file $tripletorefseq'\n");
    my @triptorefseq = <MYDATA>;
close MYDATA;

my %refseqtotrip = ();
my @refseqsformbgd = ();
foreach(@triptorefseq) {
    my @splitline = split(/\t/, $_);
    chomp $splitline[1];
    chomp $splitline[0];
    $refseqtotrip{$splitline[1]} = $splitline[0];
}

my @singleinput = split(/\s/, $mergedinput);

$mergedinput = ""; 

foreach(@singleinput) {
    my $theinput = $_;
    chomp $theinput;
    chop $theinput;
    chop $theinput;
    chop $theinput;

    my $presplitreplicons = $refseqaffiliations{$theinput};
    my @replikons = split(/\s/, $presplitreplicons); # added this
    
    foreach(@replikons) {
        my $refseqoutputfile = $_ . ".gb"; # added .gb
        $mergedinput = $mergedinput . $refseqoutputfile . ",";
        my $accessionnumber = $_;
        if (exists $refseqtotrip{$accessionnumber}) {
            push(@refseqsformbgd, $accessionnumber);
        }
        print $versiondirectory  . "get_refseq_from_ftp.sh $accessionnumber\n"; ## edit 1.2.1
        system $versiondirectory . "get_refseq_from_ftp.sh $accessionnumber"; ## edit 1.2.1
    }
    chop $mergedinput;
    $mergedinput = $mergedinput . " ";
}

my $mergedrefids = "";

foreach(@refseqsformbgd) {
    $mergedrefids = $mergedrefids . $_ . " ";    
}

chop $mergedrefids;

############################################
##                                        ##
## refseq correct DL check for 2nd chance ## ## edit 1.2.5
##                                        ##
############################################

my @files = ();
@files = <*gb>;

foreach(@files) {
    open(GBDATA, $_) or die("Error: cannot open file $_'\n");
        my @gblines = <GBDATA>;
    close GBDATA;

    my $lastLine = $gblines[-1];
    if ($lastLine =~ m/^\/\//) {
        # all is good
    } else {
        system "rm $_"; # remove file to try download again later
    }
}


################################
##                            ##
## refseq availability check  ##
##                            ##
################################

@files = ();

my @totalrefseqFiles = split(/\s|,/, $mergedinput);
my $consistencyswitch = 1;

my $limitloops = 0;

my $sleeptimer = 30; ## edit 1.2.0
while($consistencyswitch) {
    @files = ();
    @files = <*gb>;
    foreach(@totalrefseqFiles) {
        chomp $_;
        my $value = $_;
        if(grep( /^$value$/, @files )) { $consistencyswitch = 0;
        } else {
             $limitloops++;
             $consistencyswitch = 1;
 
             if($limitloops > 50) { $consistencyswitch = 0; }
             my $refOut = $_;
             my $accNr = $_;
             chop $accNr;
             chop $accNr;
             chop $accNr;
             sleep $sleeptimer; ## edit 1.2.0
             $sleeptimer = $sleeptimer * 1.1; ## edit 1.2.0
             print "next try: " . $versiondirectory . "get_refseq_from_ftp.sh $accNr\n"; ## edit 1.2.0 ## edit 1.2.1
             system $versiondirectory ."get_refseq_from_ftp.sh $accNr"; ## edit 1.2.1
             last;
        }
    }
}

### end availability check


########################################
###                                   ##
### refseq correct DL check kill job  ## ## edit 1.2.5
###                                   ##
########################################

@files = ();
@files = <*gb>;

foreach(@files) {
    open(GBDATA, $_) or die("Error: cannot open file $_'\n");
        my @gblines = <GBDATA>;
    close GBDATA;

    my $lastLine = $gblines[-1];
    if ($lastLine =~ m/^\/\//) {
        # all is good
    } else {
        die "File $_ did not download correctly. This is probably due to a connectivity issue on your or the NCBI's side. Please try to resubmit your job later (~30 min.).\n"; # kill
    }
}


## fixing issue with CONTIG and ORIGIN both in gbk file (can't parse without this) ## edit 1.2.4

@files = ();
@files = <*gb>;

foreach (@files) {
    system "sed -i '/^CONTIG/d' $_"; ## d stands for delete
}

#### end quickfix

## edit 1.2.2 adding new exception check ######################
@files = ();
@files = <*gb>;

foreach (@files) {
    system "$versiondirectory" . "check_for_gene_CDS_features.pl $_ >> gene_CDS_exception.txt";
}

open(MYDATA, "gene_CDS_exception.txt") or die("Error: cannot open file gene_CDS_exception.txt at homology_intaRNA.pl\n");
    my @exception_lines = <MYDATA>;
close MYDATA;


if (scalar(@exception_lines) >= 1) {
    my $exceptionRefSeqs = "";
    foreach(@exception_lines) {
        my @split = split(/\s+/,$_);
        $exceptionRefSeqs = $exceptionRefSeqs . $split[-1] . " ";
    }
    die("Error: gene but no CDS features present in $exceptionRefSeqs.\n This is most likely connected to currently corrupted RefSeq record(s) at the NCBI.\nPlease resubmit your job without the currently errorous organism(s) or wait some time with your resubmission.\nUsually the files are fixed within ~1 week.\n"); ## edit 1.2.2 added \n
}

## end CDS gene exception check



##########################
##                      ##
## get MBGD cluster.tab ##
##                      ##
##########################


my @tabCheck = ();
@tabCheck = <*tab>;

unless ($tabCheck[0]) { # only do if cluter.tab has not been imported

### get AA fasta for homolog clustering

@files = ();
@files = <*gb>;

foreach(@files) {
    system $versiondirectory . "get_CDS_from_gbk.pl $_ >> all.fas";
}


system "/usr/bin/formatdb -i all.fas";

system "/usr/bin/blastall -a 4 -p blastp -d all.fas -e 0.001 -i all.fas -Y 1e9 -v 30000 -b 30000 -m 8 -o all.fas.blast"; # change the -a parameter to qdjust core usage

system $versiondirectory . "blast2homfile.pl -distconv all.fas.blast > all.fas.hom";

system $versiondirectory . "fasta2genefile.pl all.fas";

system $versiondirectory . "DomClust/domclust/bin-Linux/domclust all.fas.hom all.fas.gene -HO -S -c60 -p0.5 -V0.6 -C80 -o5 > cluster.tab";

}

##########################
##                      ##
## 16s sequence parsing ##
##                      ##
##########################




my $mainreplikons = "";
my @singleinput2 = split(/\s/, $mergedforputtogether);

foreach(@singleinput2) {
    my @replikons = split(/,/, $_);
    $mainreplikons = $mainreplikons . $replikons[0] . ".gb ";
}
chomp $mainreplikons;
chop $mainreplikons;

print $versiondirectory . "parse_16s_from_gbk.pl $mergedinput > 16s_sequences.fa\n";


system $versiondirectory . "parse_16s_from_gbk.pl $mergedinput > 16s_sequences.fa";

### check 16s

open(MYDATA, "16s_sequences.fa") or die("Error: cannot open file 16s_sequences.fa\n");
    my @sixteenSseqs = <MYDATA>;
close MYDATA;

my $sixteenScounter = 0;
foreach (@sixteenSseqs) {
    if ($_ =~ m/>/) {
        $sixteenScounter++;
    }
}

if ($sixteenScounter ne $orgcount) { die("Error: wrong number of sequences in 16s_sequences.fa\n"); }

####################
##                ##
##  call Pipes    ##
##                ##
####################

print $versiondirectory . "prepare_intarna_out.pl $ncrnas $upfromstartpos $down $mrnapart $mergedinput\n";
system $versiondirectory . "prepare_intarna_out.pl $ncrnas $upfromstartpos $down $mrnapart $mergedinput";

### check fastas 

## eit 1.2.2 silencing this exception

#@files = ();
#@files = <*.fa*>;

#foreach(@files) {

#open(MYDATA, $_) or die("Error: cannot open file $_\n");
#    my @the_test_lines = <MYDATA>;
#close MYDATA;

#if (scalar(@the_test_lines) < 1) { die("Unexpected empty fasta file $_\n"); }

#}

## end fasta check
#######################################

@files = ();
@files = <*>;
my $mergedinput2 = '';

foreach (@files) {
    if ($_ =~ m/final\.csv/) {
        $mergedinput2 = $mergedinput2 . $_ . " ";
    }
}
chomp $mergedinput2;

print $versiondirectory . "scale_clusters.pl $orgcount 16s_sequences.fa $ncrnaname $mergedinput2\n";

system $versiondirectory . "scale_clusters.pl $orgcount 16s_sequences.fa $ncrnaname $mergedinput2";

print $versiondirectory . "get_genname_genid_note_from_gbk_25_11_11.pl final.list $mergedinput > final.csv\n";

system $versiondirectory . "get_genname_genid_note_from_gbk_25_11_11.pl final.list $mergedinput > final.csv";

system "uniq final.csv > final_uniq.csv";

my $absolutfinalname = $ncrnaname . "_hIntaRNA.csv";


system $versiondirectory . "remove_smaller_50perc_homology.pl final_uniq.csv $orgcount > final_filter_50perchomologs.csv";

system $versiondirectory . "parse_homologs_from_domclust_table.pl final_filter_50perchomologs.csv cluster.tab > $absolutfinalname";

@files = ();
@files = <*>;

##### create positions plots

system "/usr/bin/R --slave -f " . $versiondirectory . "script_R_plots_6.r"; ## edit 1.2.0 // added new plot script

##### convert postscript files to PNG

# thumbnails

system "convert -size 170x170 -resize 170x170 -flatten -rotate 90 sRNA_regions.ps thumbnail_sRNA.png";
system "convert -size 170x170 -resize 170x170 -flatten -rotate 90 mRNA_regions.ps thumbnail_mRNA.png";

# blow up images

system "convert -density '300' -resize '700' -flatten -rotate 90 sRNA_regions.ps sRNA_regions.png";
system "convert -density '300' -resize '700' -flatten -rotate 90 mRNA_regions.ps mRNA_regions.png";


open(MYDATA, "ncrna_hIntaRNA.csv") or die("Error: cannot open file ncrna_hIntaRNA.csv\n");
    my @CopraRNA_out_lines = <MYDATA>;
close MYDATA;

if (scalar(@CopraRNA_out_lines) <= 1) {
    die("No data in ncrna_hIntaRNA.csv\n");
}


##### create DAVID enrichment table

system $versiondirectory . "termClusterReport.pl ncrna_hIntaRNA.csv 0.01"; #result goes into termClusterReport.txt


open(MYDATA, "termClusterReport.txt") or system "echo 'If you are reading this, then your prediction did not return an enrichment, your organism of interest is not in the DAVID database\nor the DAVID webservice is/was termporarily down. You can either rerun your CopraRNA\nprediction or create your enrichment manually at the DAVID homepage.' > termClusterReport.txt";
    my @enrichment_lines = <MYDATA>;
close MYDATA;

unless($enrichment_lines[0]) {
    system "echo -e 'If you are reading this, then your prediction did not return an enrichment, your organism of interest is not in the DAVID database\nor the DAVID webservice is/was termporarily down. You can either rerun your CopraRNA\nprediction or create your enrichment manually at the DAVID homepage.' > termClusterReport.txt";
}


my $allrefs = $refseqaffiliations{$ARGV[4]};
my @splitallrefs = split(/\s/,$allrefs);

my $themainrefid = $splitallrefs[0];

## fix IntaRNA raw output WARNING message for N in seq to be able to parse the interactions correctly
my $intarnafile = $themainrefid . '_upfromstartpos_' . $upfromstartpos . '_down_' . $down . '.fa.intarna'; ## edit 1.2.4
system "sed -i '/WARNING/{N;d;}' $intarnafile"; ## edit 1.2.4


system $versiondirectory . "add_padj.sh"; #edit 1.1.0

my $orgofintTargets = $themainrefid . "_upfromstartpos_" . $upfromstartpos . "_down_" . $down . ".fa";

system "cp $orgofintTargets target_sequences_orgofint.fa";

system "head CopraRNA_result_all.csv -n 101 > CopraRNA_result.csv"; # edit 1.1.0

system $versiondirectory . "print_archive_README.pl > README.txt";

## add enrichment visualization ## edit 1.2.5

system "cp $versiondirectory" . "copra_heatmap.html ."; ## edit 1.2.5 ## edit 1.2.7 (edited html file)
system "/usr/bin/R --slave -f " . $versiondirectory . "extract_functional_enriched.r"; ## edit 1.2.5 ## edit 1.2.7 (edited R code)
system $versiondirectory . "make_heatmap_json.pl enrichment.txt"; ##edit 1.2.5
system "cp $versiondirectory" . "index-thumb.html ."; ## edit 1.2.5
system "cp $versiondirectory" . "index-pdf.html ."; ## edit 1.2.6
system $versiondirectory . "phantomjs " . $versiondirectory . "rasterize.js " . "./index-thumb.html enriched_heatmap_big.png"; ## edit 1.2.5
system $versiondirectory . "phantomjs " . $versiondirectory . "rasterize.js " . "./index-pdf.html enriched_heatmap_big.pdf"; ## edit 1.2.6
system "rm index-thumb.html"; ## edit 1.2.5
system "rm index-pdf.html"; ## edit 1.2.6

## end add enrichment vis

system "rm find_gaps.txt"; # edit 1.2.7
system "rm enrichment.txt"; # edit 1.2.5
system "rm gene_CDS_exception.txt"; ## edit 1.2.2
system "rm ncrna_hIntaRNA.csv CopraRNA_pvalues.txt";
system "rm *gb";
system "rm *fa.intarna.csv";
system "rm *fa.intarna.sorted.csv";
system "rm *fa.intarna.sorted.pvals.csv";
system "rm final.list";
system "rm final.out";
system "rm final_uniq.csv";
system "rm final_filter_50perchomologs.csv";
system "rm dndout";
system "rm final.csv";
system "rm *intarna";
system "rm tags.clustered";
system 'find -regex ".*fa[0-9]+$" | xargs rm';
system "rm NC_*.fa";
system "rm error.log padj.csv all.fas all.fas.blast all.fas.phr all.fas.pin all.fas.psq formatdb.log all.fas.hom all.fas.gene all.fas.tit";
