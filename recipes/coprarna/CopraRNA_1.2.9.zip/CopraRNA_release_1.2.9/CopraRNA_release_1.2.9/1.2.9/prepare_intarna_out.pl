#!/usr/bin/perl

use strict;
use warnings;

use Parallel::ForkManager; # libparallel-forkmanager-perl
use List::MoreUtils qw(uniq);

my $ncrnas = $ARGV[0];
my $upfromstartpos = $ARGV[1]; 
my $down = $ARGV[2]; 
my $mrnapart = $ARGV[3]; 
my $refseqid = '';

my $orgcnt = (scalar(@ARGV) - 4);

my $versiondirectory = "/home/user/Bio_Software/CopraRNA/1.2.9/";

for(my $i = 4; $i <= scalar(@ARGV) - 1; $i++) {

my @splitarg = split(/,/, $ARGV[$i]);

if ($splitarg[0] =~ m/(NC_\d{6})/) {
    $refseqid = $1;
}

my $outfile = $refseqid . '_upfromstartpos_' . $upfromstartpos . '_down_' . $down . '.fa';

my $splitargcount = 1;

foreach (@splitarg) {
    my $tempOutfile = $outfile; ## edit 1.2.2
    $tempOutfile = $tempOutfile . $splitargcount; ## edit 1.2.2
    system $versiondirectory . "parse_region_from_genome.pl $_ $upfromstartpos $down $mrnapart > $tempOutfile"; ## edit 1.2.2
    $splitargcount++;   
}

}

my @files = ();
@files = <*>;
my @rfids = ();

foreach (@files) {
    if ($_ =~ m/(NC_\d+)/) {
        push (@rfids, $1)
    }
}

@rfids = uniq(@rfids);

foreach my $id (@rfids) {
    foreach my $file (@files) {
        if ($file =~ m/($id\S+\.fa)\d+/) {
             my $tempfile = $1;
             system "cat $file >> $tempfile";
        }
    }
}


my $suffix = '_upfromstartpos_' . $upfromstartpos . '_down_' . $down . '.fa';


#######################
##                   ##
## Part 2 -> IntaRNA ##
##                   ##
#######################

@files = ();
@files = <*>;
my $switch = 0;
my @ncrnaarray = (); 

open(MYDATA, $ncrnas) or die("Error: cannot open file $ncrnas'\n");
    my @ncrnalines = <MYDATA>;
close MYDATA;


foreach (@ncrnalines) {
    if ($_ =~ m/>/) {
        $_ =~ s/\r|\n|\s|\t//g;
        $_ = reverse $_;
        chop $_;
        $_ = reverse $_;
        $_ = $_ . ".fa";
        open (FILE, ">$_");
        chop $_;
        chop $_;
        chop $_;
        print FILE (">" . $_ . "\n");
    } else {
        $_ =~ s/\r|\n|\s|\t|-//g;
        $_ = lc($_);
        print FILE ($_);
    }
}
close FILE;


my $pm = new Parallel::ForkManager(4); # change the 4 to whatever amount of cores you want to run CopraRNA with   
foreach (@files) {
    if ($_ =~ m/($suffix)$/) {
        my $refid = substr $_, 0, 9;  # get refseq id NC_000000
        foreach my $line (@ncrnalines) {
            if ($switch) {                  
                push(@ncrnaarray, $line);   
                $switch = 0;                
            }                               
            if($line =~ m/($refid)/) {
                $switch = 1;
                push(@ncrnaarray, $line);
            }
        }
        my $ncrnafilename = $ncrnaarray[0]; 
        $ncrnafilename = $ncrnafilename . ".fa";
        @ncrnaarray = ();
        my $intarnaout = $_ . ".intarna";
            $pm->start and next;            
            system("/usr/local/bin/IntaRNA -p 7 -w 140 -L 70 -o -t $_ -m $ncrnafilename > $intarnaout");
            print("/usr/local/bin/IntaRNA -p 7 -w 140 -L 70 -o -t $_ -m $ncrnafilename > $intarnaout\n");
            $pm->finish;                    
     }                                                                                   
}
                                                                                        
$pm->wait_all_children;  


@files = ();
@files = <*>;

foreach (@files) {
    if ($_ =~ m/\.intarna$/) {
        my $csvout = $_ . ".csv";
        system $versiondirectory . "produce_semicolon_sep_results_from_intarna_out.pl --intarna-out-file $_ > $csvout";
    }
}


@files = ();
@files = <*>;

my $prefix = '';

foreach (@files) {
    if ($_ =~ m/(NC_\d{6}_upfromstartcdn_\d+_length_\d+\.fa\.shuffled)\.\d+\.intarna\.csv/) {
        $prefix = $1;
        my $catargument = $prefix . ".*.intarna.csv";
        my $catout = $prefix . ".intarna.csv";
        my $catout2 = $catout . "2";
        system "cat $catargument > $catout";
        system "sed \"/target/d\" $catout > $catout2";
        system "mv $catout2 $catout";
        system "cat " . $versiondirectory . "csvheader.head $catout > $catout2";
        system "mv $catout2 $catout";
    }
}
   

#############################################
##                                         ##
## Part 4 -> sort IntaRNA output by energy ##
##                                         ##
#############################################

@files = ();
@files = <*>;

foreach (@files) {
    if ($_ =~ m/csv$/) {
        my $temp = $_;
        chomp $temp;
        chop $temp;
        chop $temp;
        chop $temp;
        my $sortedcsv = $temp . "sorted.csv"; 
        system $versiondirectory . "sort_intarna_csv_results.pl --intarna-csv-file $_ --column 17 > $sortedcsv";
    }
}

@files = ();
@files = <*>;

my %ncrnalengthhash = (); 
my @lines = (); 
my @datalines = (); 

if ($mrnapart eq "cds") {
    foreach(@files) {
        if($_ =~ m/\_NC_\d{6}\.fa/) {
            open(THEDATA, $_) or die("Error: cannot open file $_'\n");
                @lines = <THEDATA>;
            close THEDATA;
            $lines[0] = substr($lines[0], 1);
            chomp $lines[0];
            chomp $lines[1];
            $ncrnalengthhash{$lines[0]} = length($lines[1]);
        }
    }
    foreach(@files) {
        if($_ =~ m/intarna\.sorted\.csv$/) {
            open(THEDATA, $_) or die("Error: cannot open file $_'\n");
                @datalines = <THEDATA>;
            close THEDATA;

        open (WRITETO, ">$_");
        print WRITETO ($datalines[0]);
        for(my $i=1; $i<scalar(@datalines); $i++) {
            my @splitlines = split(/;/, $datalines[$i]);
            my $normenergy = ($splitlines[16]/log($ncrnalengthhash{$splitlines[8]}*$splitlines[1]));
            pop @splitlines;
            foreach(@splitlines) {
                print WRITETO ($_ . ";");
            }
            print WRITETO ($normenergy . "\n");
        }
        close WRITETO;
        }
    }

}
        

###################################
##                               ##
## Part 5 -> add p-values to csv ##
##                               ##
###################################


@files = ();
@files = <*>;

foreach (@files) {
    if ($_ =~ m/(.*)\.fa\.intarna\.sorted\.csv$/) {
    my $argofinterest = $_;
    my $temp = $_;
    chomp $temp;
    chop $temp;
    chop $temp;
    chop $temp;
    my $pvalcsvout = $temp . "pvals.csv";
    system $versiondirectory . "add_pval_to_csv_evdfit.pl $argofinterest > $pvalcsvout";
    }
}

###############################################
##                                           ##
## Part 6 -> extract relevant lines from csv ##
##                                           ##
###############################################

@files = ();
@files = <*>;

foreach (@files) {
    if ($_ =~ m/(.*)\.fa\.intarna\.sorted\.pvals\.csv$/) {
        my $finalout = $1 . ".final.csv";
        chomp $finalout;
        system("cut -d ';' -f 1,4-5,9,11-12,17-18 $_ > $finalout");
    }
}



