#!/usr/bin/perl

use strict;
use warnings;

my $orgcount = $ARGV[0];
my $molchrono = $ARGV[1]; 
my $ncrnaname = $ARGV[2];
my $c = 2; 
my $mergedinput = "";

my $versiondirectory = "/home/user/Bio_Software/CopraRNA/1.2.9/";

###################################################
##                                               ##
## make msa to create later distance matrix from ##
##                                               ##
###################################################

system "/usr/bin/emma -sequence $molchrono -outseq msa.aln -dendoutfile dndout";

wait();

###########################
##                       ##
## create distancematrix ##
##                       ##
###########################

system "/usr/bin/distmat -sequence msa.aln -nucmethod 1 -outfile distmat.out";

wait();


# ich merge hier die inputs ab dem 4.[argv index 3] input um sie dann dem system aufruf zu übergeben

for ( my $i=3; $i<= (scalar(@ARGV) - 1); $i++ ) {
    $mergedinput = $mergedinput . $ARGV[$i] . " ";
}


##################################################################################
##                                                                              ##
## cluster the locus tags from the intarna targets using the MBGD cluster table ##
##                                                                              ##
##################################################################################

system $versiondirectory . "hash_clusters_domclust.pl cluster.tab $mergedinput > tags.clustered";
wait();

#############################################
##                                         ##
## calculate weights for z-score weighting ##
##                                         ##
#############################################

# transform the distmat
system $versiondirectory . "transform_distmat.pl distmat.out > compatible.distmat";

# create the trees
system "/usr/bin/fneighbor -datafile compatible.distmat -outfile compatible.fneighbor";
system "sed -i 's/0.00000/0.00001/g' compatible.fneighbor"; ## edit 1.2.9 fix zero dist between org issue
system "sed -i 's/0.00000/0.00001/g' compatible.treefile"; ## edit 1.2.9 fix zero dist between org issue

# calculate the weights
system $versiondirectory . "read_fneighfile.pl compatible.treefile compatible.fneighbor > zscore.weight";


#################################
##                             ##
## calculates combined pvalues ##
##                             ##
#################################

system "/usr/bin/R --slave -f " . $versiondirectory . "join_pvals_zscore.R"; ## edit 1.2.7
wait();


# sort the final output and return in in final.list
system "env LC_ALL=C sort -g -k1 final.out > final.list";
wait();


