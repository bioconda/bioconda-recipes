#!/usr/bin/perl

use strict;
use warnings;

my $finalfile = $ARGV[0];
my $orgcnt = $ARGV[1];

open(MYDATA, $finalfile) or die("Error: cannot open file $finalfile'\n");
    my @finalfile = <MYDATA>;
close MYDATA;

foreach(@finalfile) {
    my @split = split(/,/, $_);
    my $emptycount = 0;
    foreach(@split) {
        if(not $_) {
            $emptycount++;
        }
    }

    if ($orgcnt % 2) {
        if($emptycount < (int(($orgcnt/2) + 0.5))) {
            print "$_";
        }                                #INSERT ODD STATEMENTS HERE
    } else {
        if($emptycount <= (int(($orgcnt/2) + 0.5))) {
            print "$_";
        }                                #INSERT EVEN STATEMENTS HERE
    }

}

