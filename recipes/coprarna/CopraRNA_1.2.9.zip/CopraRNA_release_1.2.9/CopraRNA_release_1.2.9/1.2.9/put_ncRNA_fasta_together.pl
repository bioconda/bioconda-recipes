#!/usr/bin/perl

use strict;
use warnings;

my $ncRNAfasta = $ARGV[0];
# after this we get the Refseq IDs which are possibly comma sepparated

my $ncRNAname = "ncRNA";

open(MYDATA, $ncRNAfasta) or die ("Error: cannot open file $ncRNAfasta\n");

my @ncRNAlines = <MYDATA>;

close MYDATA;

my @refids = ();
for (my $i = 1; $i < scalar(@ARGV); $i++) {
    if($ARGV[$i] =~  m/,/) {
        my @splitargv = split(/,/, $ARGV[$i]);
        push(@refids, $splitargv[0]);
    } else {
        push(@refids, $ARGV[$i]);
    }
}

foreach(@ncRNAlines) {
    chomp $_;
    if($_ =~ m/>/) {
        my $refid = shift(@refids);
        print ">$ncRNAname" . "_$refid" . "\n";
    } else {
        print "$_\n";
    }
}



