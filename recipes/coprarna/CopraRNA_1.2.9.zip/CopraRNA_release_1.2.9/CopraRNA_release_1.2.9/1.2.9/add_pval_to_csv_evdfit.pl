#!/usr/bin/perl

use strict;
use warnings;

use Statistics::R;

my $csvfile = $ARGV[0];
my $fullpath = "/usr/bin/R"; 

my $R = Statistics::R->new( r_bin => $fullpath );

$R->startR ;

my $Rin = $csvfile;
$Rin = $Rin;
$R->set('myinfile', $Rin);

$R->send(q`

library(evir)

data <- read.table(myinfile, sep=";", header=TRUE)
energy <- data$energy

energy <- energy*(-1)
gevenergies <- gev(energy) # fitten
xi <- gevenergies$par.ests[1] # chi auslesen aus dem fitting
sigma <- gevenergies$par.ests[2] # sigma auslesen "    "
mu <- gevenergies$par.ests[3] # mu auslesen aus   "    "

`) ;

open(MYDATA, $csvfile) or die("Error: cannot open file' $csvfile \n");

my @csvlines = <MYDATA>;

close MYDATA;

foreach (@csvlines) {
    chomp $_;
    if ($_ =~ m/\d/) { # skip header
        my @splitarray =  split(/;/, $_);
        my $energyval = $splitarray[16];
        $R->set('myenergy', $energyval);
        $R->send(q` 
            myenergy <- myenergy * (-1)
            pval <- pgev(myenergy, xi, mu, sigma)
            pval <- as.numeric(1 - pval)
            print(pval)
        `) ;

        my $ret = $R->read;
        $ret = substr $ret, 4;
        print $_ . ";" . $ret . "\n";

    } else { print $_ . ";p-value\n"; } # print the header
}

$R->stop();

