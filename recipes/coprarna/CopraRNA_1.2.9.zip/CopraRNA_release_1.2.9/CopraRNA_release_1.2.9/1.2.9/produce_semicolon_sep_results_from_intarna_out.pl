#!/usr/bin/perl


use warnings;
use strict;
use Getopt::Long;


my $RNAfold = "/usr/local/bin";
my $RT = 0.61632;



my $help = ''; 
my $with_PU = '';
my $with_GC = '';
my $intarna_results_file = undef;
my $SD_pos_file = undef;   
my $pos_start = undef; 
my $start_codon_pos_rev = '';  
my $SD_length = undef; 
my $SD_offset = undef;
my $interact = undef;

GetOptions (
    'help|?' => \$help,
    'with-PU' => \$with_PU,
    'with-GC' => \$with_GC,
    'intarna-out-file=s' => \$intarna_results_file,
    'sd-pos-file=s' => \$SD_pos_file,
    'start-codon-pos=i' => \$pos_start,
    'start-codon-pos-rev' => \$start_codon_pos_rev,
    'sd-length=i' => \$SD_length,
    'sd-offset=i' => \$SD_offset,
    'interact'     => \$interact,
);

if ($help) {
print "\nThe script extracts all information from a file with IntaRNA results.\n",
"Optionally, it reads positions of SD sequence of target from file, ",
"calculates PU values for the SD sequence of the target before and after ",
"the predicted hybridization and calculates the GC content of the sequences.\n",
"All results are printed in a semicolon separated list.\n\n",

"The following options are available:\n",
" --with-PU                 calculate and print PU values for target SD sequence\n",
" --with-GC                 calculate and print GC content of target and sRNA\n",
" --intarna-out-file file   file with IntaRNA output\n",
" --sd-pos-file file        file with positions of target SD sequence relative to start codon,\n",
"                           print absolute SD sequence positions (required for --with-PU)\n",
" --start-codon-pos number  position of first base of start codon ",
    "(counts from 1) (required for --SD-pos-file)\n",
" --start-codon-pos-rev     start codon position counts from end of target sequence\n",
" --sd-length number        SD sequence length (required for --SD-pos-file)\n",
" --sd-offset number        SD sequence offset according to SD sequence position ",
    "(required for --SD-pos-file)\n",
" --interact                print interaction of target and sRNA\n",
" --help                    this help\n\n",

"Example:    seq. TTCCAGGAGGAACACATGAACAT, 16SrRNA 3' tail GAUCACCUCCUUA\n",
"        start codon AUG starts at pos 16\n",
"        SD seq starts with C at pos -13 relative to 1st base of AUG\n",
"        if interested only in AGGAGG set SD-length to 6 and SD-offset to 2\n";

exit(-1);
}

die "No file with IntaRNA output specified. Please use --intarna-out-file ",
    "filename.\n" if (!defined($intarna_results_file));
die "No file with SD sequence positions specified. Please use --sd-pos-file ",
    "filename.\n" if ($with_PU && !defined($SD_pos_file));
die "No start codon position specified. Please use --start-codon-pos number.\n" 
    if (defined($SD_pos_file) && !defined($pos_start));
die "No SD sequence length specified. Please use --sd-length number.\n" 
    if (defined($SD_pos_file) && !defined($SD_length));
die "No SD sequence offset specified. Please use --sd-offset number.\n" 
    if (defined($SD_pos_file) && !defined($SD_offset));


my $tmp_file = readpipe("mktemp");
chomp($tmp_file);
die "ERROR: Could not create tmp file $tmp_file\n" if (! (-e $tmp_file));


my $RNAfoldBin = "$RNAfold/RNAfold";
$RNAfoldBin =~ s/~/$ENV{HOME}/;
die  "ERROR: RNAfold binary does not exist ($RNAfoldBin)\n"    
    if (! (-e $RNAfoldBin));

open(FILE, $intarna_results_file) || 
    die "ERROR: Could not open $intarna_results_file\n";
my @intarna_results = <FILE>;
close(FILE);
chomp(@intarna_results);

my %SD_pos;
if ($SD_pos_file) {
    open(FILE, $SD_pos_file) || die "ERROR: Could not open $SD_pos_file\n";
    my @SD_pos_arr = <FILE>;
    close(FILE);
    chomp(@SD_pos_arr);
    for (my $i=0; $i<$#SD_pos_arr; $i++) {
        $SD_pos_arr[$i] =~ />\s*(.*)\|(location:.*)\|(gene[=:].*)\|(locus_tag[=:].*)/;
        $SD_pos{$1."|".$2."|".$3."|".$4} = $SD_pos_arr[++$i];
    }
}

print_header();

my ($target_name,$target_id,$target_seq,$target_region_length,$sRNA_name,
    $sRNA_seq,$energy_all,$target_GC,$sRNA_GC,
    $SD_start_pos,$SD_end_pos,
    $target_start_pos,$target_end_pos,$target_hyb_len,$target_seed_start_pos,
    $target_seed_end_pos,
    $sRNA_start_pos,$sRNA_end_pos,$sRNA_hyb_len,$sRNA_seed_start_pos,
    $sRNA_seed_end_pos,
    $target_ED,$sRNA_ED,$hybrid_energy,$energy,
    $PU_no_hybrid,$PU_hybrid,$delta_PU,
    $energy_constraint_SD_no_hybrid,$energy_constraint_hybrid,
    $energy_constraint_SD_hybrid,$interaction);

for (my $i=0; $i<=$#intarna_results; $i++) {
    if ($intarna_results[$i] =~ /^>/) {
        $intarna_results[$i] =~ 
            /^>(.*)$/;
        $target_name = $1;
        $target_id = $1;
        $intarna_results[++$i] =~ /([ACGTUN]*)/;
        $target_seq = $1;
        $target_region_length = length($target_seq);
        $intarna_results[++$i] =~ />\s*(.*)/;
        $sRNA_name = $1;
        $intarna_results[++$i] =~ /([ACGTUN]*)/;
        $sRNA_seq = $1;


        if ($with_PU) {
            $energy_all = compute_energy_all($target_id,$target_seq);
        }

        if ($with_GC) {
            $target_GC = compute_GC($target_seq);
            $target_GC = sprintf("%.2f",$target_GC);
            $sRNA_GC = compute_GC($sRNA_seq);
            $sRNA_GC = sprintf("%.2f",$sRNA_GC);
        }

        if ($SD_pos_file) {
            die "ERROR: target $target_id not found in SD pos\n" 
                if (!defined($SD_pos{$target_id}));
            if ($SD_pos{$target_id} =~ /^position\(SD\):\s+([-\d]+).*/) {
                if ($start_codon_pos_rev) {
                    $SD_start_pos = ($target_region_length-$pos_start+1) + $1 + $SD_offset;
                } else {                
                    $SD_start_pos = $pos_start + $1 + $SD_offset;
                }
                $SD_end_pos = $SD_start_pos + $SD_length - 1;
            } else {
                ($SD_start_pos, $SD_end_pos) = ("n/a","n/a");
            }
        }

        for (;$i<$#intarna_results && !($intarna_results[$i+1] =~ /^==+/); $i++) {
            if ($intarna_results[$i] =~ /\s*5'-[ACGTUN\s]*-3'/) {
                $intarna_results[$i] =~ /\s*5'-[ACGTUN]*(\s[ACGTUN\s]*\s)[ACGTUN]*-3'/;
                $interaction = "5'-".$1."-3';";
                $intarna_results[++$i] =~ /\s*([ACGTUN][ACGTUN\s]*[ACGTUN])\s*/;
                $interaction .= "   ".$1."   ;";
                $intarna_results[++$i] =~ /\s*([ACGTUN][ACGTUN\s]*[ACGTUN])\s*/;
                $interaction .= "   ".$1."   ;";
                $intarna_results[++$i] =~ /\s*3'-[ACGTUN]*(\s[ACGTUN\s]*\s)[ACGTUN]*-5'/;
                $interaction .= "3'-".$1."-5'";
                $intarna_results[$i+=2] =~
                    /positions\(target\)\s*:\s+(\d*)\s--\s(\d*)/;
                $target_start_pos = $1;
                $target_end_pos = $2;
                $target_hyb_len = $target_end_pos - $target_start_pos + 1;
                $intarna_results[++$i] =~
                    /positions seed\(target\)\s*:\s+(\d*)\s--\s(\d*)/;
                $target_seed_start_pos = $1;
                $target_seed_end_pos = $2;
                $intarna_results[$i+=2] =~
                    /positions\((?:mi|nc|s)RNA\)\s*:\s+(\d*)\s--\s(\d*)/;
                $sRNA_start_pos = $1;
                $sRNA_end_pos = $2;
                $sRNA_hyb_len = $sRNA_end_pos - $sRNA_start_pos + 1;
                $intarna_results[++$i] =~
                    /positions seed\((?:mi|nc|s)RNA\)\s*:\s+(\d*)\s--\s(\d*)/;
                $sRNA_seed_start_pos = $1;
                $sRNA_seed_end_pos = $2;
                $intarna_results[$i+=2] =~
                    /ED\starget\sneed:\s+([\d\.\-]*)\skcal\/mol/;
                $target_ED = $1;
                $target_ED = sprintf("%.5f",$target_ED);
                $intarna_results[++$i] =~
                    /ED\s(?:mi|nc|s)RNA\s*\sneed:\s+([\d\.\-]*)\skcal\/mol/;
                $sRNA_ED = $1;
                $sRNA_ED = sprintf("%.5f",$sRNA_ED);
                $intarna_results[++$i] =~
                    /hybrid\senergy\s:\s+([\d\.\-]*)\skcal\/mol/;
                $hybrid_energy = $1;
                $hybrid_energy = sprintf("%.1f",$hybrid_energy);
                $intarna_results[$i+=2] =~
                    /energy:\s+([\d\.\-]*)\skcal\/mol/;
                $energy = $1;
                $energy = sprintf("%.5f",$energy);
    
    
                if ($with_PU) {
                    if ($SD_start_pos eq "n/a" && $SD_end_pos eq "n/a") {
                        ($PU_no_hybrid, $PU_hybrid, $delta_PU) = ("n/a", "n/a", "n/a");
                    } else {
                        $energy_constraint_SD_no_hybrid = 
                            compute_energy_constraint($target_id,$target_seq,$SD_start_pos-1,$SD_end_pos-1,-1,-1);
                        $energy_constraint_hybrid =
                            compute_energy_constraint($target_id,$target_seq,$target_start_pos-1,$target_end_pos-1,-1,-1);
                        $energy_constraint_SD_hybrid =
                            compute_energy_constraint($target_id,$target_seq,$SD_start_pos-1,$SD_end_pos-1,$target_start_pos-1,$target_end_pos-1);
                        $PU_no_hybrid = compute_PU($energy_all,$energy_constraint_SD_no_hybrid);
                        $PU_no_hybrid = sprintf("%.5f",$PU_no_hybrid);
                        if ($energy_constraint_SD_hybrid eq "***") {
                            $PU_hybrid = "***";
                            $delta_PU = "***";
                        } else {
                            $PU_hybrid = 
                                compute_PU($energy_constraint_hybrid,$energy_constraint_SD_hybrid);
                            $PU_hybrid = sprintf("%.5f",$PU_hybrid);
                            $delta_PU = $PU_hybrid - $PU_no_hybrid;
                            $delta_PU = sprintf("%.5f",$delta_PU);
                        }
                    }
                }
    
                print_current_values();
            }
        }
    }
}

if (-e $tmp_file) {
    readpipe("rm $tmp_file");
}


sub compute_energy_all {
    my $name = $_[0];
    my $seq = $_[1];

    open(FILE, ">$tmp_file") || die "ERROR: Could not open $tmp_file\n";
    print FILE ">$name\n";
    print FILE "$seq\n";
    close(FILE);

    my @RNAfold_results = readpipe("$RNAfoldBin -d2 -p0 -noPS < $tmp_file");

    my $energy_all;
    foreach (@RNAfold_results) {
        if (/\sfree\senergy\sof\sensemble\s=\s+([-\d\.]+)\skcal\/mol.*/) {
            $energy_all = $1;
        }
    }

    die "ERROR: RNAfold error. Please restart script\n" 
        if (!defined($energy_all));

    return $energy_all;
}


sub compute_energy_constraint {
    my ($name,$seq,$reg1_start_pos,$reg1_end_pos,$reg2_start_pos,$reg2_end_pos) = 
        ($_[0],$_[1],$_[2],$_[3],$_[4],$_[5]);
    my $len = length($seq);

    if ( ($reg1_start_pos <= $reg2_start_pos && $reg1_end_pos >= $reg2_end_pos) ||  
        ($reg1_start_pos >= $reg2_start_pos && $reg1_end_pos <= $reg2_end_pos) ||  
        ($reg1_start_pos <= $reg2_start_pos && $reg1_end_pos >= $reg2_start_pos) ||
        ($reg1_start_pos <= $reg2_end_pos && $reg1_end_pos >= $reg2_end_pos) ) { 
        return "***";
    }
    else {
        open(FILE, ">$tmp_file") || die "ERROR: Could not open $tmp_file\n";
        print FILE ">$name\n";
        print FILE "$seq\n";
        my $constraints = "";
        for (my $i=0; $i<$len;$i++) {
            $constraints .= ".";
        }
        for (my $i=$reg1_start_pos; $i<=$reg1_end_pos; $i++) {
            substr($constraints, $i, 1) = "x";
        }
        if ($reg2_start_pos != -1 && $reg2_end_pos != -1) {
            for (my $i=$reg2_start_pos; $i<=$reg2_end_pos; $i++) { 
                substr($constraints, $i, 1) = "x";
            }
        }
        print FILE "$constraints\n";
        close(FILE);

        my @RNAfoldConstraint_results = readpipe("$RNAfoldBin -d2 -p0 -noPS -C < $tmp_file");

        my $energy_constraint;
        foreach (@RNAfoldConstraint_results) {
            if (/\sfree\senergy\sof\sensemble\s=\s+([-\d\.]+)\skcal\/mol.*/) {
                $energy_constraint = $1;
            }
        }
    die "ERROR: RNAfold error. Please restart script\n" 
        if (!defined($energy_constraint));

        return $energy_constraint;
    }
}


sub compute_PU {
    my ($energy_all,$energy_constraint) = ($_[0],$_[1]);

    my $prob_unpaired = exp ( ($energy_all - $energy_constraint) / $RT);

    return $prob_unpaired;
}


sub compute_GC {
    my ($seq) = ($_[0]);
    my $len = length($seq);

    my $GC_count = ($seq =~ tr/GC//);

    return ($GC_count / $len);
}


sub print_header {
    print "target_name;target_region_len;target_hyb_len;target_start_pos;",
          "target_end_pos;target_seed_start_pos;target_seed_end_pos;";
    print "target_SD_start_pos;target_SD_end_pos;" if ($with_PU || $SD_pos_file);
    print "target_SD_PU_no_hybrid;target_SD_PU_hybrid;delta_target_SD_PU;" if ($with_PU);
    print "target_GC;" if ($with_GC);
    print "target_ED;sRNA_name;sRNA_hyb_len;sRNA_start_pos;sRNA_end_pos;",
          "sRNA_seed_start_pos;sRNA_seed_end_pos;";
    print "sRNA_GC;" if ($with_GC);
    print "sRNA_ED;hybrid_energy;energy";
    print ";interact_target;hybrid_target;hybrid_sRNA;interact_sRNA" if ($interact);
    print "\n";
}


sub print_current_values {
    print $target_name,";",$target_region_length,";",$target_hyb_len,";",$target_start_pos,";",
          $target_end_pos,";",$target_seed_start_pos,";",$target_seed_end_pos,";";
    print $SD_start_pos,";",$SD_end_pos,";" if ($with_PU || $SD_pos_file);
    print $PU_no_hybrid,";",$PU_hybrid,";",$delta_PU,";"if ($with_PU);
    print $target_GC,";"  if ($with_GC);
    print $target_ED,";",$sRNA_name,";",$sRNA_hyb_len,";",$sRNA_start_pos,";",$sRNA_end_pos,";",
          $sRNA_seed_start_pos,";",$sRNA_seed_end_pos,";";
    print $sRNA_GC,";" if ($with_GC);
    print $sRNA_ED,";",$hybrid_energy,";",$energy;
    print ";$interaction" if ($interact);
    print "\n";
}
