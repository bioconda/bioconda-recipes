#!/bin/sh

# extract pvalues

awk -F',' '{ print $1 }' ncrna_hIntaRNA.csv > CopraRNA_pvalues.txt

# run p.adj in R 

/usr/bin/R --slave -f /home/user/Bio_Software/CopraRNA/1.2.9/calc_padj.r

# remove '"'

sed 's/"//g' padj.csv > padj2.csv
mv padj2.csv padj.csv

# paste the padj column into ncrna_hIntaRNA.csv

paste padj.csv ncrna_hIntaRNA.csv -d "," > CopraRNA_result_all.csv

