/*****************************************************************************
  splitBedMain.cpp

  (c) 2015 - Pierre Lindenbaum PhD
  @yokofakun http://plindenbaum.blogspot.com
  Univ. Nantes, France

  Licenced under the GNU General Public License 2.0 license.
******************************************************************************/
#include "splitBed.h"

using namespace std;

int split_main(int argc, char* argv[])
{
    BedSplit app;
    return app.main(argc,argv);
}


