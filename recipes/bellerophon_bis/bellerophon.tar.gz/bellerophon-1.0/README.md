[![Coverage Status](https://coveralls.io/repos/github/davebx/bellerophon/badge.svg?branch=main)](https://coveralls.io/github/davebx/bellerophon?branch=main)

# bellerophon
Filter mapped reads where the mapping spans a junction, retaining the 5-prime read.
