Thank you for downloading this MATLAB software for nonnegative matrix factorization. This package contains the following files.

README.txt
example_1.m
example_2.m
nmf.m
nnlsm_activeset.m
nnlsm_blockpivot.m
solveNormalEqComb.m

Please take a look at the description in 'nmf.m' and try to execute examples to learn how to use this software. Please send bug reports, comments, or questions to jingu@cc.gatech.edu.

Jingu Kim
