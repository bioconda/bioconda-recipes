/**
 * @addtogroup random_projection
 * @ingroup matrix
 * @{
 * @file random_projection.h
 */

/** @} */
