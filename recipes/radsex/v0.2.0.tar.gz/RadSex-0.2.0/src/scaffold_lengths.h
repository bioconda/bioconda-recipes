#pragma once
#include "utils.h"

void scaffold_lengths(const std::string& genome_file_path);
