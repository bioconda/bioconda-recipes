from .main import main

def cli():
    raise SystemExit(main())
