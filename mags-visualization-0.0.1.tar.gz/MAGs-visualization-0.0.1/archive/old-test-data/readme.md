# Test data origin

The test data is collected from a Bee Metagenome project: PRJNA977416.
Public Galaxy History: https://usegalaxy.eu/u/paulzierep/h/prjna977416-bee-use-case-1-1

Metrics:

* Quast
* GTDB
* drep
* coverm
* checkm2
* bakta