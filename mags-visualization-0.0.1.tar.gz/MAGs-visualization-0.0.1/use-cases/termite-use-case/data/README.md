History: https://usegalaxy.eu/u/santinof/h/annotation-wf-termite-use-case

NOTE: Bakta is not added yet some problem with it!