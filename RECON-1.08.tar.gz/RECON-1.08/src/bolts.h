/* standard stuff */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>


#define NAME_LEN 50
#define DEPTH 3



int32_t seq_no;
char **seq_names;
