CountMatrix
===========

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.CountMatrix
   :special-members: __init__
   :members:
