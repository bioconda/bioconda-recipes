``load``
========

.. currentmodule:: lightmotif

.. autofunction:: lightmotif.load
