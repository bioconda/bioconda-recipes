``scan``
========

.. currentmodule:: lightmotif

.. autofunction:: lightmotif.scan
