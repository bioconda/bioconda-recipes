``stripe``
==========

.. currentmodule:: lightmotif

.. autofunction:: lightmotif.stripe
