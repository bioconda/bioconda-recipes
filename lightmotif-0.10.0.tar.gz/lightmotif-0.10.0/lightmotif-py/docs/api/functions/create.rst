``create``
==========

.. currentmodule:: lightmotif

.. autofunction:: lightmotif.create
