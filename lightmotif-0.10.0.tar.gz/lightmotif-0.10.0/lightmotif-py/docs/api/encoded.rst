EncodedSequence
===============

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.EncodedSequence
   :special-members: __init__
   :members:
