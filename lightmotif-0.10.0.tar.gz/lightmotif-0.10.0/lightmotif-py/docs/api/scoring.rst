ScoringMatrix
=============

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.ScoringMatrix
   :special-members: __init__
   :members:
