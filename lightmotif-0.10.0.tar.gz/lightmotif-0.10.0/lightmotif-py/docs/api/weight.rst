WeightMatrix
============

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.WeightMatrix
   :special-members: __init__
   :members:
