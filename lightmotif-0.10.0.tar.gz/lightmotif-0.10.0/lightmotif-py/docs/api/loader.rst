Loader
======

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.Loader
    :special-members: __init__, __iter__, __next__
    :members: