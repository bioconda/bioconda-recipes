TRANSFAC Motif
==============

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.TransfacMotif
   :special-members: __init__
   :inherited-members:
   :members: