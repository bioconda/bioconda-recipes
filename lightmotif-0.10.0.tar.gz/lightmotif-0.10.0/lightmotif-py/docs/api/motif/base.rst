Motif
=====

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.Motif
   :special-members: __init__
   :members: