JASPAR Motif
============

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.JasparMotif
   :special-members: __init__
   :inherited-members:
   :members: