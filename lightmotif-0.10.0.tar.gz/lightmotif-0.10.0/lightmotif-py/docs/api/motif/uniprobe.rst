UniPROBE Motif
==============

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.UniprobeMotif
   :special-members: __init__
   :inherited-members:
   :members: