StripedSequence
===============

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.StripedSequence
   :special-members: __init__
   :members:
