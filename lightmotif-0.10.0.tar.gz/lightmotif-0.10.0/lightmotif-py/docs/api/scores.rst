StripedScores
=============

.. currentmodule:: lightmotif

.. autoclass:: lightmotif.StripedScores
   :special-members: __init__
   :members:
