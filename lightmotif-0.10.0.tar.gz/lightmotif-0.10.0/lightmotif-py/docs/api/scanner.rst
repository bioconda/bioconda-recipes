Scanner
=======

.. currentmodule:: lightmotif


.. autoclass:: lightmotif.Scanner
   :special-members: __init__, __iter__, __next__
   :members:

.. autoclass:: lightmotif.Hit
   :members:
